/**
 * ReTexify AI Pro - FIXED Universal Admin JavaScript with Multi-KI Support
 * Version: 3.5.1 - Robust Event Delegation, API-Key Management & Debug Support
 * FIXES: Connection Test, API-Key Storage, Provider Comparison
 */

jQuery(document).ready(function($) {
    console.log('🚀 ReTexify AI Pro JavaScript startet...');
    console.log('📊 AJAX URL:', retexify_ajax.ajax_url);
    console.log('🔑 Nonce:', retexify_ajax.nonce);
    
    var seoData = [];
    var currentSeoIndex = 0;
    
    // FIXED: MULTI-KI PROVIDER MANAGEMENT mit separater API-Key Speicherung
    var currentProvider = '';
    var apiKeys = {}; // Separate API-Keys für jeden Provider
    var providerModels = {};
    
    // TAB SYSTEM mit robuster Event-Delegation
    initializeTabs();
    
    // DASHBOARD INITIAL LADEN
    loadDashboard();
    
    function initializeTabs() {
        console.log('🔧 Initialisiere Tab-System...');
        
        // Event-Delegation für Tab-Buttons (funktioniert auch nach DOM-Updates)
        $(document).on('click', '.retexify-tab-btn', function(e) {
            e.preventDefault();
            var tabId = $(this).data('tab');
            console.log('📋 Tab geklickt:', tabId);
            
            // Alle Tabs deaktivieren
            $('.retexify-tab-btn').removeClass('active');
            $('.retexify-tab-content').removeClass('active');
            
            // Aktiven Tab setzen
            $(this).addClass('active');
            $('#tab-' + tabId).addClass('active');
            
            // Spezielle Tab-Aktionen
            if (tabId === 'dashboard') {
                loadDashboard();
            } else if (tabId === 'ai-settings') {
                setTimeout(initializeMultiAI, 100);
            } else if (tabId === 'system') {
                setTimeout(function() {
                    $('#retexify-test-system').trigger('click');
                }, 200);
            }
        });
        
        console.log('✅ Tab-System initialisiert');
    }
    
    function loadDashboard() {
        console.log('📊 Lade Dashboard...');
        
        $('#retexify-dashboard-content').html('<div class="retexify-loading">📊 Lade Dashboard...</div>');
        
        $.ajax({
            url: retexify_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'retexify_get_stats',
                nonce: retexify_ajax.nonce
            },
            timeout: 30000,
            success: function(response) {
                console.log('📊 Dashboard Response:', response);
                if (response.success) {
                    $('#retexify-dashboard-content').html(response.data);
                    showNotification('✅ Dashboard geladen', 'success');
                } else {
                    $('#retexify-dashboard-content').html('<div class="retexify-warning">❌ Fehler: ' + (response.data || 'Unbekannter Fehler') + '</div>');
                    showNotification('❌ Dashboard-Fehler: ' + (response.data || 'Unbekannt'), 'error');
                }
            },
            error: function(xhr, status, error) {
                console.error('❌ AJAX Fehler beim Dashboard-Laden:', status, error);
                console.error('Response Text:', xhr.responseText);
                $('#retexify-dashboard-content').html('<div class="retexify-warning">❌ Verbindungsfehler: ' + error + '</div>');
                showNotification('❌ Dashboard-Verbindungsfehler', 'error');
            }
        });
    }
    
    // DASHBOARD REFRESH mit Event-Delegation
    $(document).on('click', '#retexify-refresh-stats-badge', function(e) {
        e.preventDefault();
        console.log('🔄 Dashboard Refresh ausgelöst');
        
        var $badge = $(this);
        var originalText = $badge.html();
        $badge.html('🔄 Aktualisiere...');
        
        loadDashboard();
        
        setTimeout(function() {
            $badge.html(originalText);
        }, 2000);
    });
    
    // ==== SEO OPTIMIZER FUNKTIONEN mit Event-Delegation ====
    
    // SEO CONTENT LADEN
    $(document).on('click', '#retexify-load-seo-content', function(e) {
        e.preventDefault();
        console.log('📄 SEO Content laden ausgelöst');
        
        var $btn = $(this);
        var originalText = $btn.html();
        $btn.html('⏳ Lade SEO-Content...').prop('disabled', true);
        
        var postType = $('#seo-post-type').val() || 'post';
        console.log('📄 Post-Typ:', postType);
        
        $.ajax({
            url: retexify_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'retexify_load_seo_content',
                nonce: retexify_ajax.nonce,
                post_type: postType
            },
            timeout: 30000,
            success: function(response) {
                $btn.html(originalText).prop('disabled', false);
                console.log('📄 SEO Content Response:', response);
                
                if (response.success && response.data.items) {
                    seoData = response.data.items;
                    currentSeoIndex = 0;
                    
                    if (seoData.length > 0) {
                        $('#retexify-seo-content-list').show();
                        displayCurrentSeoPage();
                        showNotification('✅ ' + seoData.length + ' ' + postType + ' geladen!', 'success');
                    } else {
                        showNotification('❌ Keine SEO-Inhalte gefunden!', 'warning');
                    }
                } else {
                    showNotification('❌ Fehler: ' + (response.data || 'Unbekannter Fehler'), 'error');
                }
            },
            error: function(xhr, status, error) {
                $btn.html(originalText).prop('disabled', false);
                console.error('❌ AJAX Fehler beim SEO Content laden:', status, error);
                showNotification('❌ Verbindungsfehler beim Laden', 'error');
            }
        });
    });
    
    function displayCurrentSeoPage() {
        if (seoData.length === 0) {
            console.log('⚠️ Keine SEO-Daten vorhanden');
            return;
        }
        
        var current = seoData[currentSeoIndex];
        console.log('📄 Zeige SEO-Seite:', current.title);
        
        // Seitentitel und Info
        $('#retexify-current-page-title').text(current.title);
        $('#retexify-page-info').html(
            'ID: ' + current.id + ' • ' +
            'Typ: ' + current.type + ' • ' +
            'Geändert: ' + current.modified
        );
        
        // Links korrekt setzen
        $('#retexify-page-url').attr('href', current.url);
        $('#retexify-edit-page').attr('href', current.edit_url);
        
        // Counter aktualisieren
        $('#retexify-seo-counter').text((currentSeoIndex + 1) + ' / ' + seoData.length);
        
        // Aktuelle SEO-Daten anzeigen
        $('#retexify-current-meta-title').text(current.meta_title || 'Nicht gesetzt');
        $('#retexify-current-meta-description').text(current.meta_description || 'Nicht gesetzt');
        $('#retexify-current-focus-keyword').text(current.focus_keyword || 'Nicht gesetzt');
        
        // Neue Felder leeren
        $('#retexify-new-meta-title').val('');
        $('#retexify-new-meta-description').val('');
        $('#retexify-new-focus-keyword').val('');
        
        updateCharCounters();
        
        // Navigation
        $('#retexify-seo-prev').prop('disabled', currentSeoIndex === 0);
        $('#retexify-seo-next').prop('disabled', currentSeoIndex === seoData.length - 1);
        
        // Content verstecken
        $('#retexify-full-content').hide();
        
        // Ergebnis-Bereich leeren
        $('#retexify-seo-results').html('');
    }
    
    // KORRIGIERT: EINZELNES SEO-ITEM GENERIEREN mit Event-Delegation
    $(document).on('click', '.retexify-generate-single', function(e) {
        e.preventDefault();
        
        if (seoData.length === 0) {
            showNotification('❌ Keine SEO-Daten geladen', 'warning');
            return;
        }
        
        var current = seoData[currentSeoIndex];
        var $btn = $(this);
        var originalText = $btn.html();
        var seoType = $btn.data('type');
        
        $btn.html('🤖 Generiere...').prop('disabled', true);
        
        var includeCantons = $('#retexify-include-cantons').is(':checked');
        var premiumTone = $('#retexify-premium-tone').is(':checked');
        
        $.ajax({
            url: retexify_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'retexify_generate_seo_item',
                nonce: retexify_ajax.nonce,
                post_id: current.id,
                seo_type: seoType,
                include_cantons: includeCantons,
                premium_tone: premiumTone
            },
            timeout: 60000,
            success: function(response) {
                $btn.html(originalText).prop('disabled', false);
                if (response.success) {
                    var content = response.data.content;
                    var type = response.data.type;
                    
                    if (type === 'meta_title') {
                        $('#retexify-new-meta-title').val(content);
                    } else if (type === 'meta_description') {
                        $('#retexify-new-meta-description').val(content);
                    } else if (type === 'focus_keyword') {
                        $('#retexify-new-focus-keyword').val(content);
                    }
                    
                    updateCharCounters();
                    showNotification('✅ ' + seoType + ' generiert!', 'success');
                } else {
                    showNotification('❌ Fehler: ' + response.data, 'error');
                }
            },
            error: function() {
                $btn.html(originalText).prop('disabled', false);
                showNotification('❌ Verbindungsfehler bei der Generierung', 'error');
            }
        });
    });
    
    // NAVIGATION mit Event-Delegation
    $(document).on('click', '#retexify-seo-prev', function(e) {
        e.preventDefault();
        if (currentSeoIndex > 0) {
            currentSeoIndex--;
            displayCurrentSeoPage();
            showNotification('← Vorherige Seite', 'success');
        }
    });
    
    $(document).on('click', '#retexify-seo-next', function(e) {
        e.preventDefault();
        if (currentSeoIndex < seoData.length - 1) {
            currentSeoIndex++;
            displayCurrentSeoPage();
            showNotification('→ Nächste Seite', 'success');
        }
    });
    
    // CONTENT ANZEIGEN mit Event-Delegation
    $(document).on('click', '#retexify-show-content', function(e) {
        e.preventDefault();
        
        if (seoData.length === 0) {
            showNotification('❌ Keine SEO-Daten geladen', 'warning');
            return;
        }
        
        var current = seoData[currentSeoIndex];
        var $btn = $(this);
        var originalText = $btn.html();
        $btn.html('⏳ Lade Content...').prop('disabled', true);
        
        $.ajax({
            url: retexify_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'retexify_get_page_content',
                nonce: retexify_ajax.nonce,
                post_id: current.id
            },
            timeout: 30000,
            success: function(response) {
                $btn.html(originalText).prop('disabled', false);
                if (response.success) {
                    $('#retexify-content-text').text(response.data.content);
                    $('#retexify-word-count').text(response.data.word_count + ' Wörter');
                    $('#retexify-char-count').text(response.data.char_count + ' Zeichen');
                    $('#retexify-full-content').slideDown(300);
                    showNotification('📄 Content geladen', 'success');
                } else {
                    showNotification('❌ Fehler beim Laden des Contents: ' + (response.data || 'Unbekannt'), 'error');
                }
            },
            error: function(xhr, status, error) {
                $btn.html(originalText).prop('disabled', false);
                console.error('❌ AJAX Fehler beim Content laden:', status, error);
                showNotification('❌ Verbindungsfehler beim Content laden', 'error');
            }
        });
    });
    
    // CHARACTER COUNTER mit Event-Delegation
    function updateCharCounters() {
        var titleLength = $('#retexify-new-meta-title').val().length;
        var descLength = $('#retexify-new-meta-description').val().length;
        
        $('#title-chars').text(titleLength);
        $('#description-chars').text(descLength);
        
        // Farben setzen basierend auf optimalen Längen
        $('#title-chars').css('color', 
            titleLength > 60 ? '#dc3545' : 
            titleLength > 54 ? '#ffc107' : 
            titleLength > 0 ? '#28a745' : '#6c757d'
        );
        
        $('#description-chars').css('color', 
            descLength > 160 ? '#dc3545' : 
            descLength > 150 ? '#ffc107' : 
            descLength > 0 ? '#28a745' : '#6c757d'
        );
    }
    
    $(document).on('input', '#retexify-new-meta-title, #retexify-new-meta-description', updateCharCounters);
    
    // FELDER LEEREN mit Event-Delegation
    $(document).on('click', '#retexify-clear-seo-fields', function(e) {
        e.preventDefault();
        $('#retexify-new-meta-title').val('');
        $('#retexify-new-meta-description').val('');
        $('#retexify-new-focus-keyword').val('');
        updateCharCounters();
        $('#retexify-seo-results').html('');
        showNotification('🗑️ Felder geleert', 'success');
    });
    
    // ==== FIXED: MULTI-KI PROVIDER MANAGEMENT ====
    
    function initializeMultiAI() {
        console.log('🤖 Multi-KI System wird initialisiert...');
        
        // Laden der verfügbaren API-Keys
        loadApiKeys();
        
        currentProvider = $('#ai-provider').val() || 'openai';
        console.log('🤖 Aktueller Provider:', currentProvider);
        
        // Provider Info setzen
        updateProviderInfo(currentProvider);
        updateApiKeyHelp(currentProvider);
        updateProviderComparison(currentProvider);
        
        console.log('✅ Multi-KI System initialisiert');
    }
    
    // FIXED: API-Keys für alle Provider laden
    function loadApiKeys() {
        $.ajax({
            url: retexify_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'retexify_get_api_keys',
                nonce: retexify_ajax.nonce
            },
            timeout: 15000,
            success: function(response) {
                if (response.success) {
                    apiKeys = response.data;
                    console.log('🔑 API-Keys geladen:', apiKeys);
                    
                    // Aktuellen API-Key anzeigen
                    var currentProvider = $('#ai-provider').val();
                    $('#ai-api-key').val(apiKeys[currentProvider] || '');
                    
                    updateConnectionStatus(currentProvider);
                } else {
                    console.error('❌ Fehler beim Laden der API-Keys:', response.data);
                }
            },
            error: function(xhr, status, error) {
                console.error('❌ AJAX Fehler beim Laden der API-Keys:', status, error);
            }
        });
    }
    
    // FIXED: API-Key speichern
    function saveApiKey(provider, apiKey) {
        return $.ajax({
            url: retexify_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'retexify_save_api_key',
                nonce: retexify_ajax.nonce,
                provider: provider,
                api_key: apiKey
            },
            timeout: 15000
        });
    }
    
    // FIXED: Connection Status anzeigen
    function updateConnectionStatus(provider) {
        var hasApiKey = apiKeys[provider] && apiKeys[provider].length > 0;
        var $status = $('.retexify-connection-status');
        
        if ($status.length === 0) {
            // Status-Indikator erstellen falls nicht vorhanden
            $status = $('<span class="retexify-connection-status"></span>');
            $('.retexify-ai-provider-info').append($status);
        }
        
        if (hasApiKey) {
            $status.removeClass('disconnected testing').addClass('connected').text('🟢 Verbunden');
        } else {
            $status.removeClass('connected testing').addClass('disconnected').text('🔴 Nicht konfiguriert');
        }
    }
    
    // Provider Wechsel mit Event-Delegation
    $(document).on('change', '#ai-provider', function() {
        var newProvider = $(this).val();
        var oldProvider = currentProvider;
        
        console.log('🔄 Provider Wechsel:', oldProvider, '->', newProvider);
        
        if (newProvider !== oldProvider) {
            // FIXED: API-Key des alten Providers speichern vor Wechsel
            var currentApiKey = $('#ai-api-key').val();
            if (currentApiKey && oldProvider) {
                apiKeys[oldProvider] = currentApiKey;
                saveApiKey(oldProvider, currentApiKey).done(function() {
                    console.log('💾 API-Key für', oldProvider, 'gespeichert');
                });
            }
            
            switchProvider(newProvider, oldProvider);
        }
    });
    
    function switchProvider(newProvider, oldProvider) {
        currentProvider = newProvider;
        
        // Animation starten
        $('.retexify-settings-group').addClass('retexify-provider-transition');
        
        // Provider Info aktualisieren
        updateProviderInfo(newProvider);
        
        // Modelle laden
        loadModelsForProvider(newProvider);
        
        // API Key Hilfe aktualisieren
        updateApiKeyHelp(newProvider);
        
        // FIXED: Provider-Vergleich nur für aktuellen Provider
        updateProviderComparison(newProvider);
        
        // FIXED: API-Key für neuen Provider laden
        $('#ai-api-key').val(apiKeys[newProvider] || '');
        
        // Connection Status aktualisieren
        updateConnectionStatus(newProvider);
        
        // Animation beenden
        setTimeout(function() {
            $('.retexify-settings-group').removeClass('retexify-provider-transition').addClass('loaded');
            showProviderSwitchNotification(newProvider, oldProvider);
        }, 300);
    }
    
    function updateProviderInfo(provider) {
        var providerNames = {
            'openai': 'OpenAI (GPT-4, GPT-4o, etc.)',
            'anthropic': 'Anthropic Claude (3.5 Sonnet, Haiku, Opus)',
            'gemini': 'Google Gemini (Pro, Flash, etc.)'
        };
        
        $('.retexify-ai-provider-info span').first().text('🤖 Aktiv: ' + (providerNames[provider] || 'Unbekannt'));
    }
    
    function loadModelsForProvider(provider) {
        var $modelSelect = $('#ai-model');
        $modelSelect.html('<option value="">⏳ Lade Modelle...</option>').prop('disabled', true);
        
        // Modelle für Provider laden
        setTimeout(function() {
            var models = getDefaultModels(provider);
            
            $modelSelect.empty().prop('disabled', false);
            
            $.each(models, function(modelKey, modelName) {
                $modelSelect.append('<option value="' + modelKey + '">' + modelName + '</option>');
            });
            
            // Erstes Modell als Standard auswählen
            if ($modelSelect.find('option').length > 0) {
                $modelSelect.find('option:first').prop('selected', true);
                updateCostEstimation(provider, $modelSelect.val());
            }
            
            showNotification('🔄 Modelle für ' + provider + ' geladen', 'success');
        }, 500);
    }
    
    function getDefaultModels(provider) {
        var models = {
            'openai': {
                'gpt-4o-mini': 'GPT-4o Mini (Empfohlen - Günstig & Schnell)',
                'gpt-4o': 'GPT-4o (Premium - Beste Qualität)',
                'o1-mini': 'o1 Mini (Reasoning - Sehr smart)',
                'o1-preview': 'o1 Preview (Reasoning - Ultra smart)',
                'gpt-4-turbo': 'GPT-4 Turbo (Ausgewogen)',
                'gpt-4': 'GPT-4 (Klassisch)',
                'gpt-3.5-turbo': 'GPT-3.5 Turbo (Günstig)'
            },
            'anthropic': {
                'claude-3-5-sonnet-20241022': 'Claude 3.5 Sonnet (Empfohlen - Beste Balance)',
                'claude-3-5-haiku-20241022': 'Claude 3.5 Haiku (Neu - Schnell & Günstig)',
                'claude-3-opus-20240229': 'Claude 3 Opus (Premium - Beste Qualität)',
                'claude-3-sonnet-20240229': 'Claude 3 Sonnet (Ausgewogen)',
                'claude-3-haiku-20240307': 'Claude 3 Haiku (Schnell & Günstig)'
            },
            'gemini': {
                'gemini-1.5-pro-latest': 'Gemini 1.5 Pro (Empfohlen - Beste Qualität)',
                'gemini-1.5-flash-latest': 'Gemini 1.5 Flash (Schnell & Günstig)',
                'gemini-1.5-flash-8b-latest': 'Gemini 1.5 Flash 8B (Ultra-schnell)',
                'gemini-1.0-pro-latest': 'Gemini 1.0 Pro (Klassisch)',
                'gemini-exp-1206': 'Gemini Experimental (Neueste Features)'
            }
        };
        
        return models[provider] || {};
    }
    
    function updateApiKeyHelp(provider) {
        var helpTexts = {
            'openai': 'OpenAI: Erhältlich auf <a href="https://platform.openai.com/api-keys" target="_blank">platform.openai.com</a><br>Format: sk-...',
            'anthropic': 'Anthropic: Erhältlich auf <a href="https://console.anthropic.com/" target="_blank">console.anthropic.com</a><br>Format: sk-ant-...',
            'gemini': 'Google: Erhältlich auf <a href="https://makersuite.google.com/app/apikey" target="_blank">makersuite.google.com</a><br>Format: AIza...'
        };
        
        var placeholders = {
            'openai': 'sk-proj-...',
            'anthropic': 'sk-ant-api03-...',
            'gemini': 'AIzaSy...'
        };
        
        $('#api-key-help').html(helpTexts[provider] || 'API-Schlüssel eingeben');
        $('#ai-api-key').attr('placeholder', placeholders[provider] || 'API-Schlüssel...');
    }
    
    // FIXED: Provider-Vergleich nur für aktuellen Provider
    function updateProviderComparison(provider) {
        var providerInfo = {
            'openai': {
                title: '📊 OpenAI GPT:',
                features: [
                    '✅ Sehr günstig (GPT-4o Mini)',
                    '✅ Bewährt für SEO',
                    '✅ Schnell & zuverlässig',
                    '✅ Große Modellauswahl',
                    '✅ Reasoning-Modelle (o1)'
                ]
            },
            'anthropic': {
                title: '📊 Anthropic Claude:',
                features: [
                    '✅ Ausgezeichnete Textqualität',
                    '✅ Sehr präzise Anweisungen',
                    '✅ Ethisch ausgerichtet',
                    '✅ Lange Kontexte möglich',
                    '✅ Neueste Modelle (3.5 Haiku)'
                ]
            },
            'gemini': {
                title: '📊 Google Gemini:',
                features: [
                    '✅ Innovative Technologie',
                    '✅ Multimodal capabilities',
                    '✅ Sehr kostengünstig',
                    '✅ Schnelle Performance',
                    '✅ Experimentelle Features'
                ]
            }
        };
        
        var info = providerInfo[provider];
        if (info) {
            $('#current-provider-title').text(info.title);
            
            var featuresHtml = '<ul>';
            info.features.forEach(function(feature) {
                featuresHtml += '<li>' + feature + '</li>';
            });
            featuresHtml += '</ul>';
            
            $('#current-provider-info').html(featuresHtml);
        }
    }
    
    function updateCostEstimation(provider, model) {
        // Entferne vorherige Kostenschätzung
        $('.retexify-cost-estimation').remove();
        
        if (!model) return;
        
        var costs = getCostEstimation(provider, model);
        
        if (costs) {
            var costHtml = `
                <div class="retexify-cost-estimation">
                    <h5>💰 Kostenschätzung pro Request:</h5>
                    <div class="retexify-cost-grid">
                        <div class="retexify-cost-item">
                            <span class="retexify-cost-value">$${costs.perRequest}</span>
                            <span class="retexify-cost-label">Pro SEO-Suite</span>
                        </div>
                        <div class="retexify-cost-item">
                            <span class="retexify-cost-value">${costs.speed}</span>
                            <span class="retexify-cost-label">Geschwindigkeit</span>
                        </div>
                        <div class="retexify-cost-item">
                            <span class="retexify-cost-value">${costs.quality}</span>
                            <span class="retexify-cost-label">Qualität</span>
                        </div>
                        <div class="retexify-cost-item">
                            <span class="retexify-cost-value">$${costs.per1000}</span>
                            <span class="retexify-cost-label">Per 1000 Seiten</span>
                        </div>
                    </div>
                </div>
            `;
            
            $('#ai-model').closest('.retexify-field').after(costHtml);
        }
    }
    
    function getCostEstimation(provider, model) {
        var estimates = {
            'openai': {
                'gpt-4o-mini': { perRequest: '0.001', speed: '⚡ Sehr schnell', quality: '⭐⭐⭐⭐', per1000: '1.00' },
                'gpt-4o': { perRequest: '0.015', speed: '⚡ Schnell', quality: '⭐⭐⭐⭐⭐', per1000: '15.00' },
                'o1-mini': { perRequest: '0.018', speed: '🔄 Mittel', quality: '⭐⭐⭐⭐⭐', per1000: '18.00' },
                'o1-preview': { perRequest: '0.09', speed: '⏳ Langsam', quality: '⭐⭐⭐⭐⭐', per1000: '90.00' },
                'gpt-4-turbo': { perRequest: '0.04', speed: '⚡ Mittel', quality: '⭐⭐⭐⭐⭐', per1000: '40.00' },
                'gpt-4': { perRequest: '0.12', speed: '⏳ Langsam', quality: '⭐⭐⭐⭐⭐', per1000: '120.00' },
                'gpt-3.5-turbo': { perRequest: '0.002', speed: '⚡ Sehr schnell', quality: '⭐⭐⭐', per1000: '2.00' }
            },
            'anthropic': {
                'claude-3-5-sonnet-20241022': { perRequest: '0.009', speed: '⚡ Schnell', quality: '⭐⭐⭐⭐⭐', per1000: '9.00' },
                'claude-3-5-haiku-20241022': { perRequest: '0.003', speed: '⚡ Sehr schnell', quality: '⭐⭐⭐⭐', per1000: '3.00' },
                'claude-3-opus-20240229': { perRequest: '0.045', speed: '⏳ Langsam', quality: '⭐⭐⭐⭐⭐', per1000: '45.00' },
                'claude-3-sonnet-20240229': { perRequest: '0.009', speed: '⚡ Schnell', quality: '⭐⭐⭐⭐⭐', per1000: '9.00' },
                'claude-3-haiku-20240307': { perRequest: '0.0008', speed: '⚡ Sehr schnell', quality: '⭐⭐⭐⭐', per1000: '0.80' }
            },
            'gemini': {
                'gemini-1.5-pro-latest': { perRequest: '0.003', speed: '⚡ Schnell', quality: '⭐⭐⭐⭐⭐', per1000: '3.00' },
                'gemini-1.5-flash-latest': { perRequest: '0.0002', speed: '⚡ Sehr schnell', quality: '⭐⭐⭐⭐', per1000: '0.20' },
                'gemini-1.5-flash-8b-latest': { perRequest: '0.0001', speed: '⚡ Ultra-schnell', quality: '⭐⭐⭐', per1000: '0.10' },
                'gemini-1.0-pro-latest': { perRequest: '0.001', speed: '⚡ Schnell', quality: '⭐⭐⭐⭐', per1000: '1.00' },
                'gemini-exp-1206': { perRequest: '0.001', speed: '⚡ Schnell', quality: '⭐⭐⭐⭐', per1000: '1.00' }
            }
        };
        
        return estimates[provider] && estimates[provider][model] ? estimates[provider][model] : null;
    }
    
    // Model Wechsel Handler mit Event-Delegation
    $(document).on('change', '#ai-model', function() {
        var provider = $('#ai-provider').val();
        var model = $(this).val();
        
        if (provider && model) {
            updateCostEstimation(provider, model);
            showNotification('📊 Kostenschätzung aktualisiert', 'success');
        }
    });
    
    // FIXED: API-Key Speichern beim Tippen
    $(document).on('input', '#ai-api-key', function() {
        var provider = $('#ai-provider').val();
        var apiKey = $(this).val();
        
        // Lokale Kopie aktualisieren
        apiKeys[provider] = apiKey;
        
        // Visual Feedback
        validateApiKeyFormat(provider, apiKey);
        
        // Auto-Save nach 2 Sekunden Pause
        clearTimeout(window.apiKeySaveTimeout);
        window.apiKeySaveTimeout = setTimeout(function() {
            if (apiKey.length > 10) { // Nur speichern wenn sinnvolle Länge
                saveApiKey(provider, apiKey).done(function() {
                    console.log('💾 Auto-Save API-Key für', provider);
                    updateConnectionStatus(provider);
                });
            }
        }, 2000);
    });
    
    // FIXED: API-Key Format Validierung
    function validateApiKeyFormat(provider, apiKey) {
        var $input = $('#ai-api-key');
        var $error = $('.retexify-api-key-error');
        
        if (!apiKey) {
            $input.removeClass('retexify-api-key-valid retexify-api-key-invalid');
            $error.remove();
            return;
        }
        
        var patterns = {
            'openai': /^sk-/,
            'anthropic': /^sk-ant-/,
            'gemini': /^AIza/
        };
        
        var isValid = patterns[provider] ? patterns[provider].test(apiKey) : apiKey.length > 10;
        
        if (isValid) {
            $input.removeClass('retexify-api-key-invalid').addClass('retexify-api-key-valid');
            $error.remove();
        } else {
            $input.removeClass('retexify-api-key-valid').addClass('retexify-api-key-invalid');
            
            if ($error.length === 0) {
                var errorMessages = {
                    'openai': 'OpenAI API-Schlüssel müssen mit "sk-" beginnen',
                    'anthropic': 'Anthropic API-Schlüssel müssen mit "sk-ant-" beginnen',
                    'gemini': 'Google API-Schlüssel müssen mit "AIza" beginnen'
                };
                
                $input.after('<div class="retexify-api-key-error">' + (errorMessages[provider] || 'Ungültiges API-Key Format') + '</div>');
            }
        }
    }
    
    function showProviderSwitchNotification(newProvider, oldProvider) {
        var providerNames = {
            'openai': 'OpenAI',
            'anthropic': 'Anthropic Claude',
            'gemini': 'Google Gemini'
        };
        
        var message = `🔄 Gewechselt zu ${providerNames[newProvider] || newProvider}`;
        if (oldProvider) {
            message += ` (von ${providerNames[oldProvider] || oldProvider})`;
        }
        
        showNotification(message, 'success');
    }
    
    // ==== FIXED: KI-EINSTELLUNGEN mit Event-Delegation ====
    
    // FIXED: CONNECTION TEST mit besserer Validierung
    $(document).on('click', '#retexify-ai-test-connection', function(e) {
        e.preventDefault();
        
        var $btn = $(this);
        var originalText = $btn.html();
        var provider = $('#ai-provider').val();
        var apiKey = $('#ai-api-key').val();
        
        // FIXED: Lokale Validierung VOR dem Test
        if (!apiKey || apiKey.length < 10) {
            showNotification('❌ Bitte geben Sie zuerst einen gültigen API-Schlüssel ein', 'error');
            return;
        }
        
        // FIXED: Provider-spezifische Format-Validierung
        var patterns = {
            'openai': /^sk-/,
            'anthropic': /^sk-ant-/,
            'gemini': /^AIza/
        };
        
        if (patterns[provider] && !patterns[provider].test(apiKey)) {
            var errorMessages = {
                'openai': '❌ OpenAI API-Schlüssel müssen mit "sk-" beginnen',
                'anthropic': '❌ Anthropic API-Schlüssel müssen mit "sk-ant-" beginnen',
                'gemini': '❌ Google API-Schlüssel müssen mit "AIza" beginnen'
            };
            showNotification(errorMessages[provider] || '❌ Ungültiges API-Key Format', 'error');
            return;
        }
        
        $btn.html('<span class="retexify-ai-loading">🔗 Teste Verbindung...</span>').prop('disabled', true);
        
        // Status auf "Testing" setzen
        $('.retexify-connection-status').removeClass('connected disconnected').addClass('testing').text('🟡 Teste...');
        
        var testMessages = {
            'openai': '🔗 Teste OpenAI Verbindung...',
            'anthropic': '🔗 Teste Claude Verbindung...',
            'gemini': '🔗 Teste Gemini Verbindung...'
        };
        
        showNotification(testMessages[provider] || '🔗 Teste KI-Verbindung...', 'success');
        
        // FIXED: API-Key vor Test speichern
        apiKeys[provider] = apiKey;
        saveApiKey(provider, apiKey);
        
        $.ajax({
            url: retexify_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'retexify_ai_test_connection',
                nonce: retexify_ajax.nonce
            },
            timeout: 30000,
            success: function(response) {
                $btn.html(originalText).prop('disabled', false);
                
                if (response.success) {
                    $('#retexify-ai-settings-result').html(
                        '<div class="retexify-test-success">' + response.data + '</div>'
                    );
                    
                    var successMessages = {
                        'openai': '✅ OpenAI Verbindung erfolgreich!',
                        'anthropic': '✅ Claude Verbindung erfolgreich!',
                        'gemini': '✅ Gemini Verbindung erfolgreich!'
                    };
                    
                    showNotification(successMessages[provider] || '✅ KI-Verbindung erfolgreich!', 'success');
                    updateConnectionStatus(provider);
                } else {
                    $('#retexify-ai-settings-result').html(
                        '<div class="retexify-test-warning">' + (response.data || 'Unbekannter Fehler') + '</div>'
                    );
                    showNotification('❌ Verbindung fehlgeschlagen: ' + (response.data || 'Unbekannt'), 'error');
                    $('.retexify-connection-status').removeClass('connected testing').addClass('disconnected').text('🔴 Fehler');
                }
            },
            error: function(xhr, status, error) {
                $btn.html(originalText).prop('disabled', false);
                console.error('❌ AJAX Fehler beim Connection Test:', status, error);
                showNotification('❌ Verbindungsfehler beim Test', 'error');
                $('.retexify-connection-status').removeClass('connected testing').addClass('disconnected').text('🔴 Fehler');
            }
        });
    });
    
    // FORM SUBMISSION mit Event-Delegation
    $(document).on('submit', '#retexify-ai-settings-form', function(e) {
        e.preventDefault();
        
        var provider = $('#ai-provider').val();
        var apiKey = $('#ai-api-key').val();
        var model = $('#ai-model').val();
        
        // FIXED: Lokale Validierung vor dem Speichern
        if (!validateProviderSettings(provider, apiKey, model)) {
            return false;
        }
        
        var formData = $(this).serialize();
        formData += '&action=retexify_ai_save_settings&nonce=' + retexify_ajax.nonce;
        
        var $submitBtn = $(this).find('button[type="submit"]');
        var originalText = $submitBtn.html();
        $submitBtn.html('💾 Speichere...').prop('disabled', true);
        
        // API-Key vor Speichern aktualisieren
        apiKeys[provider] = apiKey;
        saveApiKey(provider, apiKey);
        
        $.ajax({
            url: retexify_ajax.ajax_url,
            type: 'POST',
            data: formData,
            timeout: 30000,
            success: function(response) {
                $submitBtn.html(originalText).prop('disabled', false);
                if (response.success) {
                    $('#retexify-ai-settings-result').html(
                        '<div class="retexify-test-success">✅ ' + response.data + '</div>'
                    );
                    
                    showNotification('⚙️ ' + provider + ' Einstellungen gespeichert!', 'success');
                    updateConnectionStatus(provider);
                    
                    // Dashboard refresh nach erfolgreicher Speicherung
                    setTimeout(loadDashboard, 1000);
                } else {
                    $('#retexify-ai-settings-result').html(
                        '<div class="retexify-test-warning">❌ ' + (response.data || 'Unbekannter Fehler') + '</div>'
                    );
                    showNotification('❌ Speichern fehlgeschlagen: ' + (response.data || 'Unbekannt'), 'error');
                }
            },
            error: function(xhr, status, error) {
                $submitBtn.html(originalText).prop('disabled', false);
                console.error('❌ AJAX Fehler beim Speichern:', status, error);
                showNotification('❌ Verbindungsfehler beim Speichern', 'error');
            }
        });
    });
    
    function validateProviderSettings(provider, apiKey, model) {
        if (!provider) {
            showNotification('❌ Bitte wählen Sie einen KI-Provider', 'error');
            return false;
        }
        
        if (!apiKey) {
            showNotification('❌ Bitte geben Sie einen API-Schlüssel ein', 'error');
            $('#ai-api-key').focus();
            return false;
        }
        
        // Provider-spezifische API Key Validierung
        var apiKeyPatterns = {
            'openai': /^sk-/,
            'anthropic': /^sk-ant-/,
            'gemini': /^AIza/
        };
        
        if (apiKeyPatterns[provider] && !apiKeyPatterns[provider].test(apiKey)) {
            var errorMessages = {
                'openai': '❌ OpenAI API-Schlüssel müssen mit "sk-" beginnen',
                'anthropic': '❌ Anthropic API-Schlüssel müssen mit "sk-ant-" beginnen',
                'gemini': '❌ Google API-Schlüssel müssen mit "AIza" beginnen'
            };
            
            showNotification(errorMessages[provider], 'error');
            $('#ai-api-key').focus();
            return false;
        }
        
        if (!model) {
            showNotification('❌ Bitte wählen Sie ein Modell', 'error');
            $('#ai-model').focus();
            return false;
        }
        
        return true;
    }
    
    // SCHWEIZER KANTONE AUSWAHL mit Event-Delegation
    $(document).on('click', '#retexify-select-all-cantons', function(e) {
        e.preventDefault();
        $('input[name="target_cantons[]"]').prop('checked', true);
        showNotification('🇨🇭 Alle Kantone ausgewählt', 'success');
    });
    
    $(document).on('click', '#retexify-select-main-cantons', function(e) {
        e.preventDefault();
        $('input[name="target_cantons[]"]').prop('checked', false);
        // Hauptkantone: BE, ZH, LU, SG, BS, GE
        var mainCantons = ['BE', 'ZH', 'LU', 'SG', 'BS', 'GE'];
        mainCantons.forEach(function(canton) {
            $('input[name="target_cantons[]"][value="' + canton + '"]').prop('checked', true);
        });
        showNotification('🏙️ Hauptkantone ausgewählt', 'success');
    });
    
    $(document).on('click', '#retexify-clear-cantons', function(e) {
        e.preventDefault();
        $('input[name="target_cantons[]"]').prop('checked', false);
        showNotification('🗑️ Alle Kantone abgewählt', 'success');
    });
    
    // ==== SYSTEM-TEST mit Event-Delegation ====
    
    $(document).on('click', '#retexify-test-system-badge', function(e) {
        e.preventDefault();
        console.log('🧪 System-Test ausgelöst');
        
        var $badge = $(this);
        var originalText = $badge.html();
        $badge.html('🧪 Teste...').prop('disabled', true);
        
        $.ajax({
            url: retexify_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'retexify_test',
                nonce: retexify_ajax.nonce
            },
            timeout: 10000,
            success: function(response) {
                $badge.html(originalText).prop('disabled', false);
                if (response.success) {
                    $('#retexify-system-status').html(response.data);
                    showNotification('✅ System-Test erfolgreich!', 'success');
                } else {
                    $('#retexify-system-status').html('<div class="retexify-warning">' + response.data + '</div>');
                    showNotification('❌ System-Test fehlgeschlagen', 'error');
                }
            },
            error: function() {
                $badge.html(originalText).prop('disabled', false);
                $('#retexify-system-status').html('<div class="retexify-warning">Verbindungsfehler beim System-Test.</div>');
                showNotification('❌ Verbindungsfehler beim System-Test', 'error');
            }
        });
    });
    
    // ==== HILFSFUNKTIONEN ====
    
    function showNotification(message, type) {
        var bgColor = '#28a745';
        var textColor = 'white';
        var icon = '✅';
        
        if (type === 'warning') {
            bgColor = '#ffc107';
            textColor = '#1d2327';
            icon = '⚠️';
        } else if (type === 'error') {
            bgColor = '#dc3545';
            textColor = 'white';
            icon = '❌';
        }
        
        var $notification = $('<div>')
            .addClass('retexify-notification')
            .addClass(type)
            .html(icon + ' ' + message)
            .css({
                'position': 'fixed',
                'top': '20px',
                'right': '20px',
                'background': bgColor,
                'color': textColor,
                'padding': '12px 20px',
                'border-radius': '6px',
                'box-shadow': '0 4px 12px rgba(0,0,0,0.15)',
                'z-index': '9999',
                'max-width': '400px',
                'font-size': '14px',
                'font-weight': '600',
                'border': '1px solid rgba(255,255,255,0.2)'
            });
        
        $('body').append($notification);
        
        // Slide-in Animation
        $notification.css('transform', 'translateX(100%)').animate({
            transform: 'translateX(0)'
        }, 300);
        
        // Auto-remove nach 4 Sekunden
        setTimeout(function() {
            $notification.animate({
                transform: 'translateX(100%)',
                opacity: 0
            }, 300, function() {
                $(this).remove();
            });
        }, 4000);
        
        // Click to dismiss
        $notification.click(function() {
            $(this).animate({
                transform: 'translateX(100%)',
                opacity: 0
            }, 200, function() {
                $(this).remove();
            });
        });
    }
    
    // BENACHRICHTIGUNG WENN SEITE VERLASSEN WÄHREND EINES PROZESSES
    window.addEventListener('beforeunload', function(e) {
        if ($('.retexify-btn:disabled').length > 0) {
            var message = 'Eine KI-Operation läuft noch. Möchten Sie die Seite wirklich verlassen?';
            e.returnValue = message;
            return message;
        }
    });
    
    // DEBUG-INFORMATIONEN
    if (typeof retexify_ajax !== 'undefined' && retexify_ajax.debug) {
        console.log('🔧 ReTexify AI Pro Debug-Modus aktiviert');
        console.log('📊 AJAX URL:', retexify_ajax.ajax_url);
        console.log('🔑 Nonce:', retexify_ajax.nonce);
        console.log('🤖 KI aktiviert:', retexify_ajax.ai_enabled);
    }
    
    console.log('✅ ReTexify AI Pro JavaScript vollständig geladen!');
    console.log('🚀 Multi-KI System mit OpenAI, Anthropic Claude & Google Gemini bereit');
    
    // Willkommens-Nachricht (nur beim ersten Laden)
    if (!sessionStorage.getItem('retexify_welcome_shown')) {
        setTimeout(function() {
            showNotification('🇨🇭 ReTexify AI Pro bereit für universelle SEO-Optimierung!', 'success');
            sessionStorage.setItem('retexify_welcome_shown', 'true');
        }, 1000);
    }
});


// ==== EXPORT/IMPORT FUNKTIONALITÄT - AM ENDE DER JAVASCRIPT-DATEI HINZUFÜGEN ====

// Export/Import Variablen
var exportStats = {};
var currentExportData = null;
var currentImportFile = null;

// Export/Import Tab Initialisierung
$(document).on('click', '.retexify-tab-btn[data-tab="export-import"]', function() {
    console.log('🔄 Export/Import Tab aktiviert');
    setTimeout(function() {
        loadExportStats();
        initializeExportImport();
    }, 100);
});

function initializeExportImport() {
    console.log('📦 Initialisiere Export/Import System...');
    
    // Event-Delegation für alle Export/Import Events
    setupExportImportEvents();
    
    console.log('✅ Export/Import System initialisiert');
}

function setupExportImportEvents() {
    
    // EXPORT STATISTIKEN LADEN
    $(document).off('click', '#retexify-load-export-stats').on('click', '#retexify-load-export-stats', function(e) {
        e.preventDefault();
        console.log('📊 Export-Statistiken laden ausgelöst');
        
        var $badge = $(this);
        var originalText = $badge.html();
        $badge.html('📊 Lade...').prop('disabled', true);
        
        loadExportStats();
        
        setTimeout(function() {
            $badge.html(originalText).prop('disabled', false);
        }, 2000);
    });
    
    // EXPORT VORSCHAU
    $(document).off('click', '#retexify-export-preview').on('click', '#retexify-export-preview', function(e) {
        e.preventDefault();
        console.log('👁️ Export-Vorschau ausgelöst');
        
        var exportOptions = getExportOptions();
        if (!validateExportOptions(exportOptions)) {
            return;
        }
        
        var $btn = $(this);
        var originalText = $btn.html();
        $btn.html('👁️ Generiere Vorschau...').prop('disabled', true);
        
        $.ajax({
            url: retexify_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'retexify_export_preview',
                nonce: retexify_ajax.nonce,
                post_types: exportOptions.post_types,
                post_status: exportOptions.post_status,
                fields: exportOptions.fields
            },
            timeout: 30000,
            success: function(response) {
                $btn.html(originalText).prop('disabled', false);
                console.log('👁️ Export-Vorschau Response:', response);
                
                if (response.success) {
                    displayExportPreview(response.data);
                    showNotification('✅ Export-Vorschau generiert!', 'success');
                } else {
                    showNotification('❌ Fehler bei Vorschau: ' + response.data, 'error');
                }
            },
            error: function(xhr, status, error) {
                $btn.html(originalText).prop('disabled', false);
                console.error('❌ AJAX Fehler bei Export-Vorschau:', status, error);
                showNotification('❌ Verbindungsfehler bei Vorschau', 'error');
            }
        });
    });
    
    // EXPORT STARTEN
    $(document).off('click', '#retexify-export-start').on('click', '#retexify-export-start', function(e) {
        e.preventDefault();
        console.log('📤 Export starten ausgelöst');
        
        var exportOptions = getExportOptions();
        if (!validateExportOptions(exportOptions)) {
            return;
        }
        
        var $btn = $(this);
        var originalText = $btn.html();
        $btn.html('📤 Exportiere...').prop('disabled', true);
        
        // Progress Bar anzeigen
        showExportProgress();
        
        $.ajax({
            url: retexify_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'retexify_export_perform',
                nonce: retexify_ajax.nonce,
                post_types: exportOptions.post_types,
                post_status: exportOptions.post_status,
                fields: exportOptions.fields
            },
            timeout: 120000, // 2 Minuten Timeout für Export
            success: function(response) {
                $btn.html(originalText).prop('disabled', false);
                hideExportProgress();
                console.log('📤 Export Response:', response);
                
                if (response.success) {
                    displayExportSuccess(response.data);
                    showNotification('✅ Export erfolgreich! ' + response.data.total_rows + ' Zeilen exportiert', 'success');
                } else {
                    showNotification('❌ Export-Fehler: ' + response.data, 'error');
                }
            },
            error: function(xhr, status, error) {
                $btn.html(originalText).prop('disabled', false);
                hideExportProgress();
                console.error('❌ AJAX Fehler beim Export:', status, error);
                showNotification('❌ Verbindungsfehler beim Export', 'error');
            }
        });
    });
    
    // CSV DATEI AUSWAHL
    $(document).off('change', '#retexify-csv-file').on('change', '#retexify-csv-file', function(e) {
        var file = e.target.files[0];
        console.log('📁 CSV-Datei ausgewählt:', file);
        
        if (file) {
            if (file.type !== 'text/csv' && !file.name.toLowerCase().endsWith('.csv')) {
                showNotification('❌ Bitte wählen Sie eine CSV-Datei aus', 'error');
                $(this).val('');
                return;
            }
            
            if (file.size > 10 * 1024 * 1024) { // 10MB Limit
                showNotification('❌ Datei zu groß (max. 10MB)', 'error');
                $(this).val('');
                return;
            }
            
            currentImportFile = file;
            
            $('#retexify-file-name').text(file.name);
            $('#retexify-file-size').text(formatFileSize(file.size));
            $('#retexify-file-info').show();
            $('#retexify-import-start').prop('disabled', false);
            
            showNotification('✅ CSV-Datei bereit für Import', 'success');
        } else {
            currentImportFile = null;
            $('#retexify-file-info').hide();
            $('#retexify-import-start').prop('disabled', true);
        }
    });
    
    // IMPORT STARTEN
    $(document).off('click', '#retexify-import-start').on('click', '#retexify-import-start', function(e) {
        e.preventDefault();
        console.log('📥 Import starten ausgelöst');
        
        if (!currentImportFile) {
            showNotification('❌ Bitte wählen Sie zuerst eine CSV-Datei aus', 'error');
            return;
        }
        
        var $btn = $(this);
        var originalText = $btn.html();
        $btn.html('📥 Importiere...').prop('disabled', true);
        
        // Progress Bar anzeigen
        showImportProgress();
        
        var formData = new FormData();
        formData.append('action', 'retexify_import_perform');
        formData.append('nonce', retexify_ajax.nonce);
        formData.append('csv_file', currentImportFile);
        
        $.ajax({
            url: retexify_ajax.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            timeout: 120000, // 2 Minuten Timeout für Import
            success: function(response) {
                $btn.html(originalText).prop('disabled', false);
                hideImportProgress();
                console.log('📥 Import Response:', response);
                
                if (response.success) {
                    displayImportSuccess(response.data);
                    showNotification('✅ Import erfolgreich! ' + response.data.total_processed + ' Einträge verarbeitet', 'success');
                    
                    // Datei-Auswahl zurücksetzen
                    $('#retexify-csv-file').val('');
                    $('#retexify-file-info').hide();
                    currentImportFile = null;
                    $btn.prop('disabled', true);
                } else {
                    showNotification('❌ Import-Fehler: ' + response.data, 'error');
                }
            },
            error: function(xhr, status, error) {
                $btn.html(originalText).prop('disabled', false);
                hideImportProgress();
                console.error('❌ AJAX Fehler beim Import:', status, error);
                showNotification('❌ Verbindungsfehler beim Import', 'error');
            }
        });
    });
    
    // SYSTEM CHECK
    $(document).off('click', '#retexify-system-check').on('click', '#retexify-system-check', function(e) {
        e.preventDefault();
        console.log('🧪 System-Check ausgelöst');
        
        var $badge = $(this);
        var originalText = $badge.html();
        $badge.html('🧪 Teste...').prop('disabled', true);
        
        $.ajax({
            url: retexify_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'retexify_system_check',
                nonce: retexify_ajax.nonce
            },
            timeout: 30000,
            success: function(response) {
                $badge.html(originalText).prop('disabled', false);
                
                if (response.success) {
                    $('#retexify-system-check-results').html(response.data);
                    showNotification('✅ System-Check erfolgreich!', 'success');
                } else {
                    $('#retexify-system-check-results').html('<div class="retexify-warning">' + response.data + '</div>');
                    showNotification('❌ System-Check fehlgeschlagen', 'error');
                }
            },
            error: function(xhr, status, error) {
                $badge.html(originalText).prop('disabled', false);
                console.error('❌ AJAX Fehler beim System-Check:', status, error);
                $('#retexify-system-check-results').html('<div class="retexify-warning">Verbindungsfehler beim System-Check.</div>');
                showNotification('❌ Verbindungsfehler beim System-Check', 'error');
            }
        });
    });
}

function loadExportStats() {
    console.log('📊 Lade Export-Statistiken...');
    
    $('#retexify-export-stats').html('<div class="retexify-loading">Lade Export-Statistiken...</div>');
    
    $.ajax({
        url: retexify_ajax.ajax_url,
        type: 'POST',
        data: {
            action: 'retexify_export_stats',
            nonce: retexify_ajax.nonce
        },
        timeout: 30000,
        success: function(response) {
            console.log('📊 Export-Statistiken Response:', response);
            
            if (response.success) {
                exportStats = response.data;
                displayExportStats(exportStats);
                updateExportCounters();
                showNotification('✅ Export-Statistiken geladen', 'success');
            } else {
                $('#retexify-export-stats').html('<div class="retexify-warning">❌ Fehler: ' + response.data + '</div>');
                showNotification('❌ Statistik-Fehler: ' + response.data, 'error');
            }
        },
        error: function(xhr, status, error) {
            console.error('❌ AJAX Fehler bei Export-Statistiken:', status, error);
            $('#retexify-export-stats').html('<div class="retexify-warning">❌ Verbindungsfehler bei Statistiken</div>');
            showNotification('❌ Verbindungsfehler bei Statistiken', 'error');
        }
    });
}

function displayExportStats(stats) {
    var html = '<div class="retexify-stats-grid">';

    // Beiträge & Seiten zusammengefasst
    var postsPages = 0;
    if (stats.posts && stats.pages) {
        postsPages = (stats.posts.total || 0) + (stats.pages.total || 0);
    }
    html += '<div class="retexify-stat-card">';
    html += '<span class="retexify-stat-number">' + postsPages + '</span>';
    html += '<span class="retexify-stat-label">Posts/Seiten</span>';
    html += '</div>';

    // Yoast Meta-Titel
    html += '<div class="retexify-stat-card">';
    html += '<span class="retexify-stat-number">' + (stats.yoast_meta_title || 0) + '</span>';
    html += '<span class="retexify-stat-label">Yoast Meta-Titel</span>';
    html += '</div>';

    // Yoast Meta-Beschreibungen
    html += '<div class="retexify-stat-card">';
    html += '<span class="retexify-stat-number">' + (stats.yoast_meta_description || 0) + '</span>';
    html += '<span class="retexify-stat-label">Yoast Meta-Beschreibungen</span>';
    html += '</div>';

    // Yoast Focus Keywords
    html += '<div class="retexify-stat-card">';
    html += '<span class="retexify-stat-number">' + (stats.yoast_focus_keyword || 0) + '</span>';
    html += '<span class="retexify-stat-label">Yoast Focus Keywords</span>';
    html += '</div>';

    // WPBakery Meta-Titel
    html += '<div class="retexify-stat-card">';
    html += '<span class="retexify-stat-number">' + (stats.wpbakery_meta_title || 0) + '</span>';
    html += '<span class="retexify-stat-label">WPBakery Meta-Titel</span>';
    html += '</div>';

    // WPBakery Meta-Beschreibungen
    html += '<div class="retexify-stat-card">';
    html += '<span class="retexify-stat-number">' + (stats.wpbakery_meta_description || 0) + '</span>';
    html += '<span class="retexify-stat-label">WPBakery Meta-Beschreibungen</span>';
    html += '</div>';

    // Medien (Alt-Texte)
    html += '<div class="retexify-stat-card">';
    html += '<span class="retexify-stat-number">' + (stats.images ? stats.images.total : 0) + '</span>';
    html += '<span class="retexify-stat-label">Medien (Alt-Texte)</span>';
    html += '</div>';

    html += '</div>';
    $('#retexify-export-stats').html(html);
}

function updateExportCounters() {
    if (!exportStats) return;
    
    // Post-Typ Counter
    $('#posts-count').text(exportStats.post ? exportStats.post.publish || 0 : 0);
    $('#pages-count').text(exportStats.page ? exportStats.page.publish || 0 : 0);
    
    // Status Counter
    var totalPublished = (exportStats.post ? exportStats.post.publish || 0 : 0) + 
                        (exportStats.page ? exportStats.page.publish || 0 : 0);
    var totalDrafts = (exportStats.post ? exportStats.post.draft || 0 : 0) + 
                      (exportStats.page ? exportStats.page.draft || 0 : 0);
    var totalPrivate = (exportStats.post ? exportStats.post.private || 0 : 0) + 
                       (exportStats.page ? exportStats.page.private || 0 : 0);
    
    $('#published-count').text(totalPublished);
    $('#drafts-count').text(totalDrafts);
    $('#private-count').text(totalPrivate);
    
    // SEO-Daten Counter
    if (exportStats.seo_data) {
        $('#titles-count').text(totalPublished); // Alle Posts haben Titel
        $('#content-count').text(totalPublished); // Alle Posts haben Content
        $('#meta-titles-count').text(exportStats.seo_data.meta_titles || 0);
        $('#meta-descriptions-count').text(exportStats.seo_data.meta_descriptions || 0);
        $('#focus-keywords-count').text(exportStats.seo_data.focus_keywords || 0);
        $('#wpbakery-count').text(exportStats.seo_data.wpbakery_texts || 0);
        $('#alt-texts-count').text(exportStats.seo_data.alt_texts || 0);
    }
}

function getExportOptions() {
    var options = {
        post_types: [],
        post_status: [],
        fields: []
    };
    
    // Post-Typen sammeln
    $('input[name="export_post_types[]"]:checked').each(function() {
        options.post_types.push($(this).val());
    });
    
    // Post-Status sammeln
    $('input[name="export_post_status[]"]:checked').each(function() {
        options.post_status.push($(this).val());
    });
    
    // Felder sammeln
    $('input[name="export_fields[]"]:checked').each(function() {
        options.fields.push($(this).val());
    });
    
    console.log('📋 Export-Optionen:', options);
    return options;
}

function validateExportOptions(options) {
    if (options.post_types.length === 0) {
        showNotification('❌ Bitte wählen Sie mindestens einen Post-Typ aus', 'error');
        return false;
    }
    
    if (options.post_status.length === 0) {
        showNotification('❌ Bitte wählen Sie mindestens einen Status aus', 'error');
        return false;
    }
    
    if (options.fields.length === 0) {
        showNotification('❌ Bitte wählen Sie mindestens ein Feld für den Export aus', 'error');
        return false;
    }
    
    return true;
}

function displayExportPreview(previewData) {
    var html = '<div class="retexify-export-summary">';
    html += '<h6>📋 Export-Zusammenfassung:</h6>';
    html += '<div class="retexify-summary-grid">';
    
    html += '<div class="retexify-summary-item">';
    html += '<span class="retexify-summary-value">' + previewData.total_count + '</span>';
    html += '<span class="retexify-summary-label">Einträge</span>';
    html += '</div>';
    
    html += '<div class="retexify-summary-item">';
    html += '<span class="retexify-summary-value">' + previewData.selected_fields + '</span>';
    html += '<span class="retexify-summary-label">Felder</span>';
    html += '</div>';
    
    html += '<div class="retexify-summary-item">';
    html += '<span class="retexify-summary-value">' + previewData.estimated_size + '</span>';
    html += '<span class="retexify-summary-label">Geschätzte Größe</span>';
    html += '</div>';
    
    html += '</div>';
    html += '</div>';
    
    // Preview-Tabelle
    if (previewData.preview && previewData.preview.length > 0) {
        html += '<div class="retexify-export-preview">';
        html += '<h5>👁️ Vorschau (erste 10 Einträge):</h5>';
        html += '<div class="retexify-table-wrapper">';
        html += '<table class="retexify-preview-table">';
        
        // Header
        var firstRow = previewData.preview[0];
        html += '<thead><tr>';
        Object.keys(firstRow).forEach(function(key) {
            html += '<th>' + key + '</th>';
        });
        html += '</tr></thead>';
        
        // Daten
        html += '<tbody>';
        previewData.preview.forEach(function(row) {
            html += '<tr>';
            Object.values(row).forEach(function(value) {
                var displayValue = value;
                if (typeof value === 'string' && value.length > 30) {
                    displayValue = value.substring(0, 30) + '...';
                }
                html += '<td>' + (displayValue || '—') + '</td>';
            });
            html += '</tr>';
        });
        html += '</tbody>';
        
        html += '</table>';
        html += '</div>';
        html += '</div>';
    }
    
    $('#retexify-export-results').html(html).show();
}

function displayExportSuccess(exportData) {
    var html = '<div class="retexify-export-success">';
    html += '<h5>🎉 Export erfolgreich abgeschlossen!</h5>';
    html += '<p><strong>' + exportData.total_rows + '</strong> Einträge wurden exportiert.</p>';
    html += '<p>Dateigröße: <strong>' + formatFileSize(exportData.file_size) + '</strong></p>';
    html += '<p>';
    html += '<a href="' + exportData.download_url + '" class="retexify-download-link" download="' + exportData.filename + '">';
    html += '📥 CSV-Datei herunterladen';
    html += '</a>';
    html += '</p>';
    html += '<p><small>Die Datei bleibt 24 Stunden zum Download verfügbar.</small></p>';
    html += '</div>';
    
    $('#retexify-export-results').html(html).show();
}

function displayImportSuccess(importData) {
    var html = '<div class="retexify-import-success">';
    html += '<h5>🎉 Import erfolgreich abgeschlossen!</h5>';
    
    html += '<div class="retexify-import-stats">';
    html += '<div class="retexify-import-stat">';
    html += '<span class="retexify-import-stat-number">' + importData.total_processed + '</span>';
    html += '<span class="retexify-import-stat-label">Verarbeitet</span>';
    html += '</div>';
    
    html += '<div class="retexify-import-stat">';
    html += '<span class="retexify-import-stat-number">' + importData.updated + '</span>';
    html += '<span class="retexify-import-stat-label">Aktualisiert</span>';
    html += '</div>';
    
    html += '<div class="retexify-import-stat">';
    html += '<span class="retexify-import-stat-number">' + importData.imported + '</span>';
    html += '<span class="retexify-import-stat-label">Importiert</span>';
    html += '</div>';
    html += '</div>';
    
    // Fehler anzeigen falls vorhanden
    if (importData.errors && importData.errors.length > 0) {
        html += '<div class="retexify-import-errors">';
        html += '<h6>⚠️ Warnungen/Fehler (' + importData.errors.length + '):</h6>';
        html += '<ul class="retexify-error-list">';
        importData.errors.slice(0, 10).forEach(function(error) {
            html += '<li>' + error + '</li>';
        });
        if (importData.errors.length > 10) {
            html += '<li>... und ' + (importData.errors.length - 10) + ' weitere</li>';
        }
        html += '</ul>';
        html += '</div>';
    }
    
    html += '</div>';
    
    $('#retexify-import-results').html(html).show();
}

function showExportProgress() {
    var progressHtml = '<div class="retexify-progress-container">';
    progressHtml += '<div class="retexify-progress-bar">';
    progressHtml += '<div class="retexify-progress-fill" style="width: 0%"></div>';
    progressHtml += '</div>';
    progressHtml += '<p>Export wird durchgeführt...</p>';
    progressHtml += '</div>';
    
    $('#retexify-export-results').html(progressHtml).show();
    
    // Animiere Progress Bar
    var progress = 0;
    var progressInterval = setInterval(function() {
        progress += Math.random() * 15;
        if (progress > 90) progress = 90;
        
        $('.retexify-progress-fill').css('width', progress + '%');
    }, 500);
    
    // Speichere Interval für später
    window.exportProgressInterval = progressInterval;
}

function hideExportProgress() {
    if (window.exportProgressInterval) {
        clearInterval(window.exportProgressInterval);
        window.exportProgressInterval = null;
    }
    
    // Finalisiere Progress Bar
    $('.retexify-progress-fill').css('width', '100%');
}

function showImportProgress() {
    var progressHtml = '<div class="retexify-progress-container">';
    progressHtml += '<div class="retexify-progress-bar">';
    progressHtml += '<div class="retexify-progress-fill" style="width: 0%"></div>';
    progressHtml += '</div>';
    progressHtml += '<p>Import wird durchgeführt...</p>';
    progressHtml += '</div>';
    
    $('#retexify-import-results').html(progressHtml).show();
    
    // Animiere Progress Bar
    var progress = 0;
    var progressInterval = setInterval(function() {
        progress += Math.random() * 12;
        if (progress > 85) progress = 85;
        
        $('.retexify-progress-fill').css('width', progress + '%');
    }, 600);
    
    // Speichere Interval für später
    window.importProgressInterval = progressInterval;
}

function hideImportProgress() {
    if (window.importProgressInterval) {
        clearInterval(window.importProgressInterval);
        window.importProgressInterval = null;
    }
    
    // Finalisiere Progress Bar
    $('.retexify-progress-fill').css('width', '100%');
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    var k = 1024;
    var sizes = ['Bytes', 'KB', 'MB', 'GB'];
    var i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// ERWEITERTE DEBUGGING FÜR EXPORT/IMPORT
if (typeof retexify_ajax !== 'undefined' && retexify_ajax.debug) {
    console.log('🔧 ReTexify Export/Import Debug-Modus aktiviert');
    
    // Debug Export/Import Events
    $(document).on('click', '.retexify-checkbox input', function() {
        console.log('🔘 Checkbox geändert:', $(this).attr('name'), $(this).val(), $(this).is(':checked'));
    });
    
    // Debug File Selection
    $(document).on('change', 'input[type="file"]', function() {
        console.log('📁 Datei ausgewählt:', this.files[0]);
    });
}

console.log('✅ ReTexify Export/Import JavaScript vollständig geladen!');