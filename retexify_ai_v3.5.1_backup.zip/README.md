# 🚀 ReTexify AI Pro - Neue modulare Struktur

## 📁 Verzeichnisstruktur

```
retexify-ai-pro/
├── retexify.php                    # Hauptdatei (schlanker Kern)
├── inc/                            # Alle Plugin-Klassen
│   ├── class-retexify-admin.php           # Admin-Interface
│   ├── class-retexify-ajax.php            # AJAX-Handler  
│   ├── class-retexify-ai.php              # KI-Engine
│   ├── class-retexify-content-analyzer.php # Deutsche Content-Analyse
│   ├── class-retexify-seo-helper.php      # SEO Plugin Integration
│   ├── class-retexify-assets.php          # Asset Management
│   └── class-retexify-utilities.php       # Helper-Funktionen
├── assets/                         # CSS/JS (optional)
│   ├── admin-style.css             # Externe CSS (falls vorhanden)
│   └── admin-script.js             # Externes JS (falls vorhanden)
├── languages/                      # Übersetzungen
└── README.md                       # Plugin-Dokumentation
```

## 🔧 Installation

### Schritt 1: Dateien hochladen
1. Alle Dateien in `/wp-content/plugins/retexify-ai-pro/` hochladen
2. Ordnerstruktur genau einhalten
3. Plugin im WordPress-Backend aktivieren

### Schritt 2: Abhängigkeiten erstellen
Das `inc/` Verzeichnis **muss** existieren und alle Klassen-Dateien enthalten.

## 📚 Klassen-Übersicht

### 🎯 Hauptklasse (`retexify.php`)
- **Autoloader**: Lädt Klassen automatisch
- **Singleton Pattern**: Verhindert mehrfache Instanziierung  
- **Initialisierung**: Startet alle Komponenten
- **Aktivierung/Deaktivierung**: Plugin-Lifecycle

### 🖥️ Admin-Interface (`class-retexify-admin.php`)
- **Menü-Management**: WordPress Admin-Menü
- **Tab-System**: Dashboard, SEO-Optimizer, Settings, System
- **HTML-Rendering**: Alle Admin-Seiten
- **Formular-Handling**: Einstellungen und Validierung

### 🔄 AJAX-Handler (`class-retexify-ajax.php`)
- **API-Endpunkte**: Alle AJAX-Requests
- **Sicherheit**: Nonce-Validierung
- **Datenverarbeitung**: Request/Response-Logic
- **Fehlerbehandlung**: Einheitliche Error-Responses

### 🤖 KI-Engine (`class-retexify-ai.php`)
- **OpenAI Integration**: API-Aufrufe
- **Prompt-Management**: Deutsche SEO-Prompts
- **Content-Generation**: Meta-Titel, Beschreibungen, Keywords
- **Swiss Context**: Kantone und Business-Kontext

### 📝 Content-Analyzer (`class-retexify-content-analyzer.php`)
- **Deutsche Texte**: Spezielle Verarbeitung für Umlaute/ß
- **Keyword-Extraktion**: Deutsche Stopwords
- **Business-Themen**: Schweizer Innenausbau-Begriffe
- **Qualitätsbewertung**: Content-Scoring

### 🔗 SEO-Helper (`class-retexify-seo-helper.php`)
- **Multi-Plugin Support**: Yoast, Rank Math, All in One SEO, SEOPress
- **Meta-Daten**: Einheitliche API für alle SEO-Plugins
- **Validierung**: SEO-Daten prüfen
- **Scoring**: SEO-Score berechnen

### 🎨 Assets (`class-retexify-assets.php`)
- **CSS/JS Management**: Fallback-System
- **Lokalisierung**: JavaScript-Strings
- **Performance**: Nur bei Bedarf laden
- **Caching**: Versionierung

### 🛠️ Utilities (`class-retexify-utilities.php`)
- **Helper-Funktionen**: Formatierung, Validierung
- **Cache-Management**: Transients mit Fallback
- **System-Info**: Performance-Monitoring
- **Debugging**: Erweiterte Log-Funktionen

## 🚀 Vorteile der neuen Struktur

### ✅ Saubere Trennung
- Jede Klasse hat eine klare Aufgabe
- Keine 2000+ Zeilen-Dateien mehr
- Bessere Übersichtlichkeit

### ✅ Einfache Wartung
- Bugs schneller finden und beheben
- Neue Features gezielt hinzufügen
- Code-Reviews effizienter

### ✅ Bessere Performance
- Autoloader lädt nur benötigte Klassen
- Modulares Asset-Loading
- Intelligentes Caching

### ✅ Erweiterbarkeit
- Neue Klassen einfach hinzufügen
- Bestehende Klassen erweitern
- Plugin-System für Add-ons

### ✅ Debugging
- Jede Komponente einzeln testbar
- Bessere Error-Isolation
- Detailliertes Logging

## 📖 Wie man neue Features hinzufügt

### 1. Neue Klasse erstellen
```php
<?php
// inc/class-retexify-neue-funktion.php

class Retexify_Neue_Funktion {
    public function __construct() {
        // Initialisierung
    }
    
    public function meine_methode() {
        // Funktionalität
    }
}
```

### 2. In Hauptklasse integrieren
```php
// In retexify.php -> load_components()
$this->neue_funktion = new Retexify_Neue_Funktion();
```

### 3. AJAX-Handler hinzufügen (falls nötig)
```php
// In class-retexify-ajax.php -> register_ajax_hooks()
add_action('wp_ajax_meine_neue_aktion', array($this, 'handle_neue_aktion'));
```

## 🔧 Troubleshooting

### Problem: "Class not found"
**Lösung**: 
- Prüfen ob `inc/` Verzeichnis existiert
- Klassenname mit Dateiname abgleichen
- Schreibweise beachten (class-retexify-name.php)

### Problem: AJAX funktioniert nicht
**Lösung**:
- Nonce prüfen
- `wp_ajax_*` Hooks registriert?
- JavaScript-Konsole auf Fehler prüfen

### Problem: CSS/JS laden nicht
**Lösung**:
- `assets/` Verzeichnis vorhanden?
- Fallback auf Inline-Code funktioniert
- Cache leeren

## 🔄 Migration von der alten Version

### Automatische Migration
Die neue Struktur ist **abwärtskompatibel**:
- Bestehende Einstellungen bleiben erhalten
- Keine Datenverluste
- Funktionalität identisch

### Manuelle Schritte
1. **Backup erstellen** (empfohlen)
2. Alte Plugin-Dateien löschen
3. Neue Dateien hochladen
4. Plugin neu aktivieren

## 🧪 Entwicklung & Testing

### Debug-Modus aktivieren
```php
// wp-config.php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
```

### Logs anzeigen
```bash
tail -f /wp-content/debug.log | grep "ReTexify"
```

### Performance messen
```php
Retexify_Utilities::start_timer('mein_test');
// ... Code ...
Retexify_Utilities::end_timer('mein_test');
```

## 🆕 Geplante Erweiterungen

Mit der neuen modularen Struktur sind folgende Features einfach hinzufügbar:

- **Export/Import-Modul**: CSV-Funktionalität
- **Bulk-Editor**: Massen-SEO-Bearbeitung  
- **Analytics-Integration**: Performance-Tracking
- **Template-System**: SEO-Vorlagen
- **Multi-Language**: Zusätzliche Sprachen
- **API-Endpoints**: REST API für externe Tools

## 📞 Support

Bei Problemen mit der neuen Struktur:

1. **Debug-Logs prüfen** (`/wp-content/debug.log`)
2. **System-Test ausführen** (Plugin → System-Tab)
3. **Cache leeren** (`Retexify_Utilities::clear_cache()`)
4. **Abhängigkeiten prüfen** (`Retexify_Utilities::check_dependencies()`)

---

**Die neue modulare Struktur macht das Plugin wartbarer, erweiterbarer und performance-optimierter! 🚀**
