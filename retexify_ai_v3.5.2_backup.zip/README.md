# 🇨🇭 ReTexify AI Pro - Universal SEO Optimizer

**Universelles WordPress SEO-Plugin mit KI-Integration für alle Branchen. Multi-KI-Support (OpenAI, Claude, Gemini), Schweizer Qualität.**

---

## ✨ Hauptfunktionen

-   **Intelligenter SEO-Optimizer:** Analysieren Sie Ihre Beiträge und Seiten und optimieren Sie diese mit einem Klick.
-   **Multi-KI-Support:** Wählen Sie den für Sie passenden KI-Provider: OpenAI (GPT-Modelle), Anthropic (Claude-Modelle) oder Google (Gemini-Modelle).
-   **Automatische SEO-Generierung:** Erstellen Sie automatisch Meta-Titel, Meta-Beschreibungen und Fokus-Keywords basierend auf dem Inhalt Ihrer Seite.
-   **Flexible Optimierungs-Ziele:** Wählen Sie aus verschiedenen Optimierungs-Fokussen wie "Schweizer Local SEO", "Conversion", "E-Commerce" oder "B2B".
-   **Breite Plugin-Kompatibilität:** Speichert die generierten Daten direkt in den führenden SEO-Plugins (Yoast SEO, Rank Math, All in One SEO, SEOPress).
-   **Content-Dashboard:** Erhalten Sie einen schnellen Überblick über den SEO-Zustand Ihrer gesamten Website mit einem übersichtlichen SEO-Score.
-   **Schweiz-Fokus:** Berücksichtigen Sie gezielt Schweizer Kantone für optimiertes Local SEO.
-   **System-Analyse:** Überprüfen Sie auf einen Blick, ob Ihr System für den optimalen Einsatz bereit ist.

## 🔧 Installation

1.  Laden Sie das Plugin als ZIP-Datei herunter.
2.  Gehen Sie in Ihrem WordPress-Backend zu `Plugins > Installieren`.
3.  Klicken Sie auf `Plugin hochladen` und wählen Sie die heruntergeladene ZIP-Datei aus.
4.  Aktivieren Sie das Plugin nach der Installation.

## 🚀 Verwendung

1.  Navigieren Sie im WordPress-Menü zu **ReTexify AI Pro**.
2.  Wechseln Sie zum Tab **KI-Einstellungen**.
3.  Wählen Sie Ihren bevorzugten KI-Provider, geben Sie Ihren API-Schlüssel ein und passen Sie den Business-Kontext an. Speichern Sie die Einstellungen.
4.  Wechseln Sie zum Tab **SEO-Optimizer**.
5.  Laden Sie den SEO-Content für Ihre Beiträge oder Seiten.
6.  Wählen Sie einen Beitrag aus und generieren Sie entweder einzelne SEO-Elemente oder die komplette SEO-Suite mit einem Klick.
7.  Speichern Sie die neuen SEO-Daten. Diese werden automatisch in Ihr aktives SEO-Plugin übernommen.

## ⚙️ Systemanforderungen

-   WordPress 5.0 oder höher
-   PHP 7.4 oder höher

## ✅ Unterstützte SEO-Plugins

-   Yoast SEO
-   Rank Math
-   All in One SEO Pack
-   SEOPress

## 📝 Version

Aktuelle Version: **3.5.1**

## 👨‍💻 Autor

Imponi

## 📜 Lizenz

GPL v2 oder später
