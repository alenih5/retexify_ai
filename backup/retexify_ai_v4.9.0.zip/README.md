# 🚀 ReTexify AI - Universal SEO Optimizer v4.8.0

[![WordPress](https://img.shields.io/badge/WordPress-5.0+-blue.svg)](https://wordpress.org/)
[![PHP](https://img.shields.io/badge/PHP-7.2+-green.svg)](https://php.net/)
[![License](https://img.shields.io/badge/License-GPL%20v2-orange.svg)](https://www.gnu.org/licenses/gpl-2.0.html)
[![Version](https://img.shields.io/badge/Version-4.8.0-brightgreen.svg)](https://github.com/imponi/retexify-ai)

> **Universelles WordPress SEO-Plugin mit KI-Integration für alle Branchen**

ReTexify AI ist ein fortschrittliches WordPress-Plugin, das KI-gestützte SEO-Optimierung für Unternehmen aller Branchen bietet. Mit intelligenter Keyword-Recherche, automatischer Meta-Tag-Generierung und umfassenden Export/Import-Funktionen optimiert es Ihre Website für maximale Sichtbarkeit in Suchmaschinen.

## ✨ **Features**

### 🤖 **KI-gestützte SEO-Optimierung**
- **Automatische Meta-Tag-Generierung** mit OpenAI, Anthropic und Google Gemini
- **Intelligente Keyword-Recherche** mit Wettbewerbsanalyse
- **Content-Optimierung** für Schweizer Märkte
- **Mehrsprachige Unterstützung** (Deutsch, Schweizerdeutsch, Französisch, Italienisch)

### 🎯 **SEO-Tools**
- **Meta-Titel Generator** - Optimierte Titel für bessere CTR
- **Meta-Beschreibung Generator** - Ansprechende Snippets
- **Keyword Generator** - Relevante Keywords für Ihre Branche
- **Komplette SEO-Optimierung** - All-in-One Lösung

### 🔍 **Intelligente Keyword-Recherche**
- **Google Suggest API** - Aktuelle Suchtrends
- **Wikipedia API** - Thematische Erweiterungen
- **OpenStreetMap API** - Lokale SEO-Optimierung
- **Wettbewerbsanalyse** - Konkurrenz-Insights

### 📤 **Export/Import-System**
- **CSV-Export** aller Inhalte mit Vorschau
- **CSV-Import** mit Datenvalidierung
- **Bulk-Processing** für große Datenmengen
- **Automatische Backup-Erstellung**

### 🔧 **System-Diagnostik**
- **API-Verbindungstests** für alle Provider
- **System-Status-Überwachung**
- **Anforderungsprüfung**
- **Fehlerprotokollierung**

## 🚀 **Schnellstart**

### 📋 **Voraussetzungen**
- WordPress 5.0 oder höher
- PHP 7.2 oder höher
- API-Schlüssel für OpenAI, Anthropic oder Google Gemini

### 🔧 **Installation**

1. **Plugin herunterladen**
   ```bash
   # ZIP-Archiv herunterladen
   wget https://github.com/imponi/retexify-ai/releases/download/v4.8.0/retexify_ai_v4.8.0.zip
   ```

2. **In WordPress installieren**
   - Gehen Sie zu **WordPress Admin → Plugins → Plugin hinzufügen**
   - Klicken Sie auf **Plugin hochladen**
   - Wählen Sie die ZIP-Datei aus
   - Klicken Sie auf **Jetzt installieren**

3. **Plugin aktivieren**
   - Klicken Sie auf **Plugin aktivieren**
   - Gehen Sie zu **ReTexify AI** im Admin-Menü

### ⚙️ **Konfiguration**

1. **API-Schlüssel einrichten**
   ```
   ReTexify AI → KI-Einstellungen → API-Schlüssel
   ```

2. **Provider auswählen**
   - OpenAI GPT-4
   - Anthropic Claude
   - Google Gemini

3. **Einstellungen anpassen**
   - Sprache: Deutsch/Schweizerdeutsch
   - Branche: Ihr Geschäftsbereich
   - Zielgruppe: Schweizer Kunden

## 🎨 **Verwendung**

### 📊 **Dashboard**
Das Dashboard bietet eine Übersicht über:
- **SEO-Statistiken** Ihrer Website
- **System-Status** und API-Verbindungen
- **Schnellzugriff** auf alle Funktionen

### 🎯 **SEO-Optimizer**
1. **Seite auswählen** - Wählen Sie eine Seite oder einen Beitrag
2. **Content laden** - Automatisches Laden des Inhalts
3. **SEO generieren** - KI-gestützte Optimierung
4. **Daten speichern** - Automatisches Speichern der Meta-Tags

### 🔍 **Keyword-Recherche**
1. **Keyword eingeben** - Ihr Hauptkeyword
2. **Recherche starten** - Automatische Analyse
3. **Vorschläge prüfen** - Relevante Keywords
4. **Wettbewerb analysieren** - Konkurrenz-Insights

### 📤 **Export/Import**
1. **Export starten** - CSV-Export aller Inhalte
2. **Daten bearbeiten** - Externe Bearbeitung
3. **Import vorbereiten** - CSV-Datei vorbereiten
4. **Import durchführen** - Daten zurück importieren

## 🔧 **API-Integration**

### 🤖 **Unterstützte KI-Provider**

#### OpenAI
```php
// Konfiguration
'provider' => 'openai',
'model' => 'gpt-4o-mini',
'max_tokens' => 2000,
'temperature' => 0.7
```

#### Anthropic
```php
// Konfiguration
'provider' => 'anthropic',
'model' => 'claude-3-sonnet-20240229',
'max_tokens' => 2000,
'temperature' => 0.7
```

#### Google Gemini
```php
// Konfiguration
'provider' => 'gemini',
'model' => 'gemini-1.5-flash',
'max_tokens' => 2000,
'temperature' => 0.7
```

### 🔌 **API-Endpunkte**

#### SEO-Generierung
```javascript
// Meta-Titel generieren
jQuery.post(ajaxurl, {
    action: 'retexify_generate_meta_title',
    post_id: 123,
    nonce: retexify_ajax.nonce
});
```

#### Keyword-Recherche
```javascript
// Keyword-Recherche starten
jQuery.post(ajaxurl, {
    action: 'retexify_keyword_research',
    keyword: 'schweizer seo',
    nonce: retexify_ajax.nonce
});
```

#### System-Tests
```javascript
// API-Verbindung testen
jQuery.post(ajaxurl, {
    action: 'retexify_test_api_connection',
    provider: 'openai',
    nonce: retexify_ajax.nonce
});
```

## 📊 **Performance**

### ⚡ **Optimierungen**
- **Lazy Loading** von Komponenten
- **Intelligente Caching** von API-Responses
- **Optimierte Asset-Einbindung**
- **Asynchrone Verarbeitung**

### 📈 **Benchmarks**
- **SEO-Generierung**: ~2-5 Sekunden
- **Keyword-Recherche**: ~3-8 Sekunden
- **System-Tests**: ~1-3 Sekunden
- **Export/Import**: ~10-30 Sekunden (abhängig von Datenmenge)

## 🛡️ **Sicherheit**

### 🔐 **Sicherheitsmaßnahmen**
- **Nonce-Verifikation** für alle AJAX-Calls
- **Capability-Checks** (manage_options)
- **Input-Validierung** und Sanitization
- **Error-Logging** ohne sensible Daten

### 🔒 **Datenschutz**
- **Keine Datenübertragung** an unbefugte Drittanbieter
- **Lokale Verarbeitung** wo möglich
- **Verschlüsselte API-Kommunikation**
- **DSGVO-konform**

## 🚀 **Entwicklung**

### 📋 **Roadmap**
- **v4.4.0**: Erweiterte KI-Modelle und Bulk-Processing
- **v4.5.0**: Erweiterte Wettbewerbsanalyse
- **v5.0.0**: Neue UI/UX und Mobile-Optimierung

### 🔧 **Beitragen**
1. **Fork** das Repository
2. **Feature-Branch** erstellen (`git checkout -b feature/AmazingFeature`)
3. **Änderungen committen** (`git commit -m 'Add some AmazingFeature'`)
4. **Branch pushen** (`git push origin feature/AmazingFeature`)
5. **Pull Request** erstellen

### 🐛 **Bug Reports**
Bitte erstellen Sie ein Issue mit:
- **WordPress-Version**
- **PHP-Version**
- **Plugin-Version**
- **Fehlerbeschreibung**
- **Screenshots** (falls relevant)

## 📄 **Lizenz**

Dieses Projekt ist unter der **GPL v2** Lizenz lizenziert - siehe [LICENSE](LICENSE) Datei für Details.

## 👨‍💻 **Entwickler**

**Imponi** - Schweizer Webentwicklung
- **Website**: [imponi.ch](https://imponi.ch)
- **Email**: info@imponi.ch
- **GitHub**: [@imponi](https://github.com/imponi)

## 🙏 **Danksagungen**

- **WordPress Community** für das großartige CMS
- **OpenAI, Anthropic, Google** für die KI-APIs
- **Alle Mitwirkenden** und Tester

## 📞 **Support**

### 🆘 **Hilfe benötigt?**
- **Dokumentation**: [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md)
- **Issues**: [GitHub Issues](https://github.com/imponi/retexify-ai/issues)
- **Email**: support@imponi.ch

### 💡 **Tipps**
- **API-Schlüssel** regelmäßig überprüfen
- **System-Status** vor wichtigen Aktionen prüfen
- **Backups** vor großen Imports erstellen
- **Updates** regelmäßig installieren

---

**⭐ Wenn Ihnen ReTexify AI gefällt, geben Sie uns einen Stern auf GitHub!**

**Letzte Aktualisierung**: 02.07.2025  
**Version**: 4.8.0  
**Entwickler**: Imponi 

**Version 4.7.0**

Universelles WordPress SEO-Plugin mit KI-Integration für alle Branchen. Jetzt noch modularer, schneller und wartbarer!

## Highlights der Version 4.7.0

- 🧹 **Code-Bereinigung:** Entfernte Altklassen (`ReTexify_German_Content_Analyzer`, `ReTexify_SEO_Generator`)
- 🧩 **Modularisierung:** Klare Trennung von Textverarbeitung, Keyword-Analyse, Content-Klassifizierung, Schweizer Analyse und Strategie-Generierung
- 🚀 **Performance:** Weniger Code, schnellere Ladezeiten
- 📦 **Neue ZIP:** `retexify_ai_v4.4.0_cleaned.zip` und `retexify_ai_v4.4.0_final.zip`
- 📄 **Changelog:** Siehe `CHANGELOG.md` für alle Details

## Installation
1. ZIP-Datei im WordPress-Backend hochladen
2. Plugin aktivieren
3. API-Key in den Einstellungen hinterlegen

## Verzeichnisstruktur (ab 4.4.0)
```
includes/
├── class-intelligent-keyword-research.php
├── class-german-text-processor.php
├── class-keyword-analyzer.php
├── class-content-classifier.php
├── class-swiss-local-analyzer.php
├── class-keyword-strategy.php
├── class-ai-engine.php
├── class-admin-renderer.php
├── class-api-manager.php
├── class-export-import-manager.php
├── class-system-status.php
└── class_retexify_config.php
```

## Support
Fragen, Feedback oder Feature-Wünsche? [imponi.ch](https://imponi.ch/) 

## Version 4.7.1
- Export-Vorschau zeigt jetzt drei Icons (Gesamt-Posts, Spalten, Vorschau) nebeneinander
- Übersichtlicheres, modernes Layout 

> **Neu in v4.8.0:**
> - 🖥️ Modernes System-Status-Icon (Computer)
> - Alle Status-Informationen in einer einheitlichen, modernen Box
> - Code-Bereinigung und UI-Verbesserung 